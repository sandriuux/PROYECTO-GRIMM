function mostrarInfo(id) {
    var wesen = wesenInfo.find(function (w) {
        return w.id === id;
    });

    if (wesen) {
        var nombreInput = document.getElementById('nombre');
        var imagenInput = document.getElementById('imagen');
        var tipoSelect = document.getElementById('tipo');
        var peligrosidadSelect = document.getElementById('peligrosidad');
        var descripcionTextarea = document.getElementById('descripcion');
        var notasTextarea = document.getElementById('notas');

        nombreInput.value = wesen.nombre;
        imagenInput.value = wesen.imagen;
        tipoSelect.value = wesen.tipo;
        peligrosidadSelect.value = wesen.peligrosidad;
        descripcionTextarea.value = wesen.descripcion;
        notasTextarea.value = wesen.notas;
    }else{
        alert('Wesen no encontrado');
    }
}


var wesenInfo = [
    {
        id: 'alpe',
        nombre: 'Alpe',
        imagen: 'https://static.wikia.nocookie.net/grimm/images/8/80/606-Beverly_Garwood_woged.png/revision/latest/scale-to-width-down/150?cb=20170212063836',
        tipo: 'Pesadilla',
        peligrosidad: 'Peligroso',
        descripcion: 'El Alpe es una criatura de la mitología alpina que se asemeja a un espíritu maligno. Se dice que se sienta en el pecho de las personas mientras duermen y les provoca pesadillas.',
        notas: ' El término "pesadilla" proviene de la creencia en la influencia de esta criatura, ya que "pesadilla" se deriva de "mará", un nombre alternativo para el Alpe.'

    },
    {
        id: 'anubis',
        nombre: 'Anubis',
        imagen: 'https://static.wikia.nocookie.net/grimm/images/3/3d/503-Peter_woged.png/revision/latest/scale-to-width-down/150?cb=20151117183059',
        tipo: 'Chacal',
        peligrosidad: 'Neutral',
        descripcion: ' Anubis es un Wesen basado en la mitología egipcia. Toma la forma de un hombre con cabeza de chacal y está relacionado con la muerte y el más allá.',
        notas: ' Anubis es conocido como el dios egipcio encargado de guiar a las almas a la vida después de la muerte y juzgar sus corazones en el proceso de momificación.'
    },
    {
        id: 'apgadniek',
        nombre: 'Apgadniek',
        imagen: 'https://static.wikia.nocookie.net/grimm/images/3/3d/503-Peter_woged.png/revision/latest/scale-to-width-down/150?cb=20151117183059',
        tipo: 'Husky',
        peligrosidad: 'Neutral',
        descripcion: 'El Apgandnieks es un Wesen de la serie de televisión Grimm que se asemeja a un gato montés gigante. Son cazadores expertos y tienen una gran agilidad.',
        notas: ' El Apgandnieks es una criatura misteriosa y sigilosa que a menudo se oculta en los bosques, lo que lo hace difícil de detectar.'
    },
    {
        id: 'aswang',
        nombre: 'Aswang',
        imagen: 'https://static.wikia.nocookie.net/grimm/images/e/ef/314-Aswang.png/revision/latest/scale-to-width-down/150?cb=20140308061645',
        tipo: 'Demonio',
        peligrosidad: 'Pacifico',
        descripcion: 'El Aswang es una criatura del folclore filipino que se considera un chupasangre o un ser devorador de carne. Puede cambiar de forma y se alimenta de sangre humana.',
        notas: 'El Aswang es una figura muy temida en la mitología filipina y ha inspirado numerosas historias de terror y películas en Filipinas.'
    },
    {
        id: 'fusible ataktos',
        nombre: 'Fusible Ataktos',
        imagen: 'https://static.wikia.nocookie.net/grimm/images/8/8b/605-Ataktos_Fuse2.jpg/revision/latest/scale-to-width-down/150?cb=20170205021008',
        tipo: 'Cigarra',
        peligrosidad: 'Peligroso',
        descripcion: 'El Ataktos Fuse es un Wesen en la serie Grimm que se asemeja a un hombre-lobo. Cuando se transforma, adquiere características de lobo, como pelaje y garras afiladas.',
        notas: 'Este Wesen es una referencia a la leyenda del hombre lobo en la cultura popular, donde las personas pueden transformarse en lobos durante la luna llena.'
    },
    {
        id: 'balam',
        nombre: 'Balam',
        imagen: 'https://static.wikia.nocookie.net/grimm/images/7/7a/Balam.png/revision/latest/scale-to-width-down/150?cb=20130422044923',
        tipo: 'Jaguar',
        peligrosidad: 'Violento',
        descripcion: 'Balam es un Wesen en la serie Grimm que toma la forma de un jaguar. Es conocido por su astucia y su capacidad para desplazarse sigilosamente en la selva.',
        notas: 'El nombre "Balam" se deriva de la mitología maya, donde es un espíritu o dios relacionado con la adivinación y la protección.',

    },
    {
        id: 'osifraga barbatus',
        nombre: 'Osifraga Barbatus',
        imagen: 'https://static.wikia.nocookie.net/grimm/images/1/1f/518-Barbatus_Ossifrage.png/revision/latest/scale-to-width-down/150?cb=20160423193651',
        tipo: 'Quebrantahuesos',
        peligrosidad: 'Violento',
        descripcion: ' El Barbatus Ossifrage es un Wesen de Grimm que se asemeja a un buitre con la capacidad de detectar la muerte inminente de las personas.',
        notas: 'Su nombre "Ossifrage" se refiere a su hábito de alimentarse de huesos, y "Barbatus" proviene de su apariencia con una barba de plumas en el cuello.'


    },
    {
        id:'bauerschwein',
        nombre: 'Bauerschwein',
        imagen: 'https://static.wikia.nocookie.net/grimm/images/5/5e/410-Acker_woged.jpg/revision/latest/scale-to-width-down/150?cb=20150124190828',
        tipo: 'Cerdo',
        peligrosidad: 'Pacifico',
        descripcion:'Los Bauerschwein son Wesen en Grimm que tienen rasgos similares a cerdos o jabalíes. Son conocidos por su habilidad en la alquimia y la metalurgia.',
        notas:'El término "Bauerschwein" se traduce como "cerdo de granja" en alemán y hace referencia a su conexión con la vida rural.'
    },
    {
        id:'coyoti',
        nombre: 'Coyoti',
        imagen:'https://static.wikia.nocookie.net/grimm/images/5/56/408-Belem_woged.jpg/revision/latest/scale-to-width-down/150?cb=20141215031248',
        tipo:'Coyote',
        peligrosidad:'Peligroso',
        descripcion:'El Coyoti es un Wesen que se asemeja a un coyote y se caracteriza por su astucia.',
        notas:'los Coyoti son conocidos por su habilidad para aprovechar las oportunidades, lo que refleja la adaptabilidad y versatilidad de los coyotes en la vida real.'
    },

    {
        id:'blutbad',
        nombre: 'Blutbad',
        imagen:'https://static.wikia.nocookie.net/grimm/images/1/17/606-Monroe_woged.png/revision/latest/scale-to-width-down/150?cb=20170212063909',
        tipo:'Lobo',
        peligrosidad:'Violento',
        descripcion:' Los Blutbad son Wesen en Grimm que se asemejan a lobos. Son depredadores y a menudo se ven involucrados en situaciones violentas.',
        notas:'El término "Blutbad" es una combinación de las palabras alemanas "blut" (sangre) y "bad" (baño), lo que refleja su naturaleza carnívora.'

    }

];

function WesenNuevo() {
    var nombre = document.getElementById('nombre').value;
    var imagen = document.getElementById('imagen').value;
    var tipo = document.getElementById('tipo').value;
    var peligrosidad = document.getElementById('peligrosidad').value;
    var descripcion = document.getElementById('descripcion').value;
    var notas = document.getElementById('notas').value;


    var nuevoWesen = {
        id: nombre,
        nombre: nombre,
        imagen: imagen,
        tipo: tipo,
        peligrosidad: peligrosidad,
        descripcion: descripcion,
        notas: notas
    };

   
    wesenInfo.push(nuevoWesen);

    var newRow = document.createElement('tr');
    newRow.id = nuevoWesen.id;

    var nameCell = document.createElement('td');
    nameCell.textContent = nombre;
    nameCell.onclick = function() {
        mostrarInformacion(nuevoWesen.id);
    };

    var imageCell = document.createElement('td');
    var wesenImage = document.createElement('img');
    wesenImage.style.width = "140px";
    wesenImage.style.height = "130px";
    wesenImage.src = imagen;
    wesenImage.alt = nombre;
    wesenImage.onclick = function() {
        mostrarInformacion(nuevoWesen.id);
    };
    imageCell.appendChild(wesenImage);

    newRow.appendChild(nameCell);
    newRow.appendChild(imageCell);

    var tableBody = document.querySelector('.list-container tbody');
    tableBody.appendChild(newRow);

    document.getElementById('nombre').value = '';
    document.getElementById('imagen').value = '';
    document.getElementById('tipo').value = '';
    document.getElementById('peligrosidad').value = '';
    document.getElementById('descripcion').value = '';
    document.getElementById('notas').value = '';

    mostrarInformacion(nuevoWesen.id);
    resetearFormulario()
    return false;
}
function guardar() {
    var id = document.getElementById('nombre').value.toLowerCase();
    var nombre = document.getElementById('nombre').value;
    var imagen = document.getElementById('imagen').value;
    var tipo = document.getElementById('tipo').value;
    var peligrosidad = document.getElementById('peligrosidad').value;
    var descripcion = document.getElementById('descripcion').value;
    var notas = document.getElementById('notas').value;

    var wesen = wesenInfo.find(function (w) {
        return w.id === id;
    });

   
    wesen.nombre = nombre;
    wesen.imagen = imagen;
    wesen.tipo = tipo;
    wesen.peligrosidad = peligrosidad;
    wesen.descripcion = descripcion;
    wesen.notas = notas;

    
    return false;
}

function reset() {
    
    document.getElementById('nombre').value = '';
    document.getElementById('imagen').value = '';
    document.getElementById('tipo').value = '';
    document.getElementById('peligrosidad').value = '';
    document.getElementById('descripcion').value = '';
    document.getElementById('notas').value = '';
}

function eliminar() {
    var tableBody = document.querySelector('.list-container tbody');
    tableBody.removeChild(tableBody.lastElementChild);
  }

